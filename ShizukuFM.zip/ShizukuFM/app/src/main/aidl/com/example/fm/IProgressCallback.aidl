package com.example.fm;
interface IProgressCallback {
    void onProgress(long fileDone, long fileTotal, long done, long total, String name, int idx, int count);
}
