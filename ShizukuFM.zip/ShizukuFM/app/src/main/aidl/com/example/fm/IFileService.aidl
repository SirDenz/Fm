package com.example.fm;
import com.example.fm.IProgressCallback;
interface IFileService {
    void destroy() = 16777114;
    String[] list(String path);
    boolean transfer(in String[] srcs, String dstDir, boolean move, IProgressCallback cb);
    boolean delete(String path);
    boolean mkdir(String path);
}
