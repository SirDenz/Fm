package com.example.fm

import java.io.File

/** Runs inside the Shizuku shell process (uid 2000), so it can reach Android/data and Android/obb. */
class FileService : IFileService.Stub() {

    override fun destroy() { System.exit(0) }

    override fun list(path: String): Array<String> =
        File(path).listFiles()?.map {
            "${if (it.isDirectory) 1 else 0}|${it.length()}|${it.lastModified()}|${it.name}"
        }?.toTypedArray() ?: emptyArray()

    override fun delete(path: String) = File(path).deleteRecursively()
    override fun mkdir(path: String) = File(path).mkdirs()

    override fun transfer(srcs: Array<String>, dstDir: String, move: Boolean, cb: IProgressCallback): Boolean = try {
        val jobs = ArrayList<Pair<File, File>>()
        fun walk(s: File, d: File) {
            if (s.isDirectory) { d.mkdirs(); s.listFiles()?.forEach { walk(it, File(d, it.name)) } }
            else jobs.add(s to d)
        }
        srcs.forEach { val s = File(it); walk(s, File(dstDir, s.name)) }

        val total = jobs.sumOf { it.first.length() }
        var done = 0L
        var lastReport = 0L
        jobs.forEachIndexed { i, (s, d) ->
            val size = s.length()
            d.parentFile?.mkdirs()
            if (s.canonicalPath == d.canonicalPath) { done += size; return@forEachIndexed }
            if (move && s.renameTo(d)) {
                done += size
            } else {
                var fileDone = 0L
                s.inputStream().use { input ->
                    d.outputStream().use { out ->
                        val buf = ByteArray(256 * 1024)
                        var n: Int
                        while (input.read(buf).also { n = it } > 0) {
                            out.write(buf, 0, n)
                            fileDone += n; done += n
                            val now = System.currentTimeMillis()
                            if (now - lastReport > 150) {
                                lastReport = now
                                cb.onProgress(fileDone, size, done, total, s.name, i, jobs.size)
                            }
                        }
                    }
                }
                if (move) s.delete()
            }
            cb.onProgress(size, size, done, total, s.name, i + 1, jobs.size)
        }
        if (move) srcs.forEach { File(it).deleteRecursively() } // leftover empty folders
        true
    } catch (e: Exception) { false }
}
