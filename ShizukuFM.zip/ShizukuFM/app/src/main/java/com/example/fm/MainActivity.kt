package com.example.fm

import android.app.Application
import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.IBinder
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Entry(val name: String, val dir: Boolean, val size: Long, val mtime: Long)
data class Prog(
    val fileDone: Long = 0, val fileTotal: Long = 1, val done: Long = 0, val total: Long = 1,
    val name: String = "", val idx: Int = 0, val count: Int = 0, val etaSec: Long = -1, val move: Boolean = false
)

class VM(app: Application) : AndroidViewModel(app) {
    val root = "/storage/emulated/0"
    var path by mutableStateOf(root)
    var entries by mutableStateOf(listOf<Entry>())
    var selected by mutableStateOf(setOf<String>())
    var clip by mutableStateOf<Pair<List<String>, Boolean>?>(null)
    var prog by mutableStateOf<Prog?>(null)
    var status by mutableStateOf("Shizuku غير متصل")
    private var svc: IFileService? = null

    private val args = Shizuku.UserServiceArgs(ComponentName(app.packageName, FileService::class.java.name))
        .daemon(false).processNameSuffix("fs").version(1)
    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            svc = IFileService.Stub.asInterface(b); status = "Shizuku متصل ✓"; refresh()
        }
        override fun onServiceDisconnected(n: ComponentName) { svc = null; status = "Shizuku غير متصل" }
    }

    fun connect() {
        if (!Shizuku.pingBinary()) { status = "شغّل Shizuku أولاً"; return }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) { Shizuku.requestPermission(1); return }
        Shizuku.bindUserService(args, conn)
    }

    fun refresh() = viewModelScope.launch(Dispatchers.IO) {
        val list = svc?.list(path)?.map {
            val p = it.split("|", limit = 4); Entry(p[3], p[0] == "1", p[1].toLong(), p[2].toLong())
        } ?: File(path).listFiles()?.map { Entry(it.name, it.isDirectory, it.length(), it.lastModified()) } ?: emptyList()
        // ZArchiver-style order: folders first, then files, A→Z
        entries = list.sortedWith(compareByDescending<Entry> { it.dir }.thenBy { it.name.lowercase() })
        selected = emptySet()
    }

    fun go(p: String) { path = p; refresh() }
    fun up() { val par = File(path).parent ?: root; go(if (par.length < root.length) root else par) }
    fun toggle(n: String) { selected = if (n in selected) selected - n else selected + n }
    fun copy(move: Boolean) { clip = selected.map { "$path/$it" } to move; selected = emptySet() }

    fun delete() = viewModelScope.launch(Dispatchers.IO) {
        selected.forEach { svc?.delete("$path/$it") }; refresh()
    }
    fun mkdir(name: String) = viewModelScope.launch(Dispatchers.IO) { svc?.mkdir("$path/$name"); refresh() }

    fun paste() {
        val (srcs, move) = clip ?: return
        val s = svc ?: run { status = "اتصل بـ Shizuku أولاً"; return }
        val dst = path
        viewModelScope.launch(Dispatchers.IO) {
            var ema = 0.0; var lastDone = 0L; var lastT = System.currentTimeMillis()
            val cb = object : IProgressCallback.Stub() {
                override fun onProgress(fd: Long, ft: Long, d: Long, t: Long, n: String, i: Int, c: Int) {
                    val now = System.currentTimeMillis(); val dt = now - lastT
                    if (dt >= 500) { // smoothed speed → remaining time
                        val inst = (d - lastDone) * 1000.0 / dt
                        ema = if (ema == 0.0) inst else ema * 0.7 + inst * 0.3
                        lastDone = d; lastT = now
                    }
                    val eta = if (ema > 0) ((t - d) / ema).toLong() else -1
                    prog = Prog(fd, ft, d, t, n, i, c, eta, move)
                }
            }
            prog = Prog(move = move)
            val ok = s.transfer(srcs.toTypedArray(), dst, move, cb)
            prog = null; clip = null
            if (!ok) status = "فشلت العملية"
            refresh()
        }
    }

    init {
        Shizuku.addBinderReceivedListenerSticky { connect() }
        Shizuku.addRequestPermissionResultListener { _, r -> if (r == PackageManager.PERMISSION_GRANTED) connect() }
        refresh()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                App(viewModel())
            }
        }
    }
}

fun fmtSize(b: Long): String {
    if (b < 1024) return "$b B"
    val u = arrayOf("KB", "MB", "GB", "TB"); var v = b.toDouble(); var i = -1
    while (v >= 1024 && i < 3) { v /= 1024; i++ }
    return "%.1f %s".format(v, u[i])
}
fun fmtEta(s: Long) = when {
    s < 0 -> "…"; s >= 3600 -> "${s / 3600}س ${s % 3600 / 60}د"
    s >= 60 -> "${s / 60}د ${s % 60}ث"; else -> "${s}ث"
}

@Composable
fun Act(i: ImageVector, t: String, f: () -> Unit) =
    TextButton(f) { Icon(i, null); Spacer(Modifier.width(4.dp)); Text(t) }

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun App(vm: VM) {
    var newDir by remember { mutableStateOf<String?>(null) }
    BackHandler(vm.selected.isNotEmpty() || vm.path != vm.root) {
        if (vm.selected.isNotEmpty()) vm.selected = emptySet() else vm.up()
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(vm.path.removePrefix(vm.root).ifEmpty { "/" }, maxLines = 1)
                        Text(vm.status, style = MaterialTheme.typography.labelSmall)
                    }
                },
                actions = {
                    IconButton({ newDir = "" }) { Icon(Icons.Filled.CreateNewFolder, null) }
                    IconButton({ vm.connect(); vm.refresh() }) { Icon(Icons.Filled.Refresh, null) }
                }
            )
        },
        bottomBar = {
            Column {
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Android/data", "Android/obb", "Download", "DCIM").forEach {
                        AssistChip(onClick = { vm.go("${vm.root}/$it") }, label = { Text(it) })
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    if (vm.selected.isNotEmpty()) {
                        Act(Icons.Filled.ContentCopy, "نسخ") { vm.copy(false) }
                        Act(Icons.Filled.ContentCut, "نقل") { vm.copy(true) }
                        Act(Icons.Filled.Delete, "حذف") { vm.delete() }
                    } else if (vm.clip != null) {
                        Act(Icons.Filled.ContentPaste, "لصق هنا") { vm.paste() }
                        Act(Icons.Filled.Close, "إلغاء") { vm.clip = null }
                    }
                }
            }
        }
    ) { pad ->
        val fmt = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }
        LazyColumn(Modifier.padding(pad)) {
            if (vm.path != vm.root) item {
                ListItem(
                    modifier = Modifier.clickable { vm.up() },
                    leadingContent = { Icon(Icons.Filled.ArrowUpward, null) },
                    headlineContent = { Text("..") }
                )
            }
            items(vm.entries, key = { it.name }) { e ->
                val sel = e.name in vm.selected
                val date = fmt.format(Date(e.mtime))
                ListItem(
                    modifier = Modifier.combinedClickable(
                        onClick = {
                            if (vm.selected.isNotEmpty()) vm.toggle(e.name)
                            else if (e.dir) vm.go("${vm.path}/${e.name}")
                        },
                        onLongClick = { vm.toggle(e.name) }
                    ),
                    colors = ListItemDefaults.colors(containerColor = if (sel) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent),
                    leadingContent = { Icon(if (e.dir) Icons.Filled.Folder else Icons.Filled.InsertDriveFile, null) },
                    headlineContent = { Text(e.name, maxLines = 1) },
                    supportingContent = { Text(if (e.dir) date else "${fmtSize(e.size)}  •  $date") }
                )
            }
        }
    }

    vm.prog?.let { p ->
        AlertDialog(
            onDismissRequest = {}, confirmButton = {},
            title = { Text(if (p.move) "جارٍ النقل…" else "جارٍ النسخ…") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(p.name, maxLines = 1)
                    LinearProgressIndicator(progress = { p.fileDone.toFloat() / maxOf(p.fileTotal, 1) }, modifier = Modifier.fillMaxWidth())
                    Text("الملف الحالي: ${(p.fileDone * 100 / maxOf(p.fileTotal, 1))}%")
                    Spacer(Modifier.height(8.dp))
                    Text("الإجمالي: ${p.idx}/${p.count} ملف")
                    LinearProgressIndicator(progress = { p.done.toFloat() / maxOf(p.total, 1) }, modifier = Modifier.fillMaxWidth())
                    Text("${p.done * 100 / maxOf(p.total, 1)}%  •  ${fmtSize(p.done)} / ${fmtSize(p.total)}")
                    Text("الوقت المتبقي: ${fmtEta(p.etaSec)}")
                }
            }
        )
    }
    newDir?.let { n ->
        AlertDialog(
            onDismissRequest = { newDir = null },
            title = { Text("مجلد جديد") },
            text = { TextField(n, { newDir = it }, singleLine = true) },
            confirmButton = { TextButton({ if (n.isNotBlank()) vm.mkdir(n.trim()); newDir = null }) { Text("إنشاء") } }
        )
    }
}
